package com.example.ssunapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class DataBase extends SQLiteOpenHelper {


    public final static String DB_NAME = "ssun.sql";
    public final static int DB_VERSION = 2;

    public static final String user_tab_name = "user";
    public static final String user_tab_id = "id_user";
    public static final String user_tab_username = "user_name";
    public static final String user_tab_usermail = "user_mail";
    public static final String user_tab_password = "user_pass";
    public static final String noter_tab_name = "noter";
    public static final String noter_tab_id_noter = "noter_id";
    public static final String noter_tab_title = "noter_title";
    public static final String noter_tab_fag = "noter_fag";
    public static final String noter_tab_larer = "noter_larer";
    public static final String noter_tab_description = "noter_des";

    public static final String noter_tab_img = "noter_img";

    //---------------------------------------------------------------------------------------------

    public DataBase(@Nullable Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        sqLiteDatabase.execSQL("CREATE TABLE " + user_tab_name + "(" + user_tab_id + " INTEGER PRIMARY KEY AUTOINCREMENT," + user_tab_username + " TEXT," + user_tab_usermail + " TEXT," + user_tab_password + " TEXT)");
        sqLiteDatabase.execSQL("CREATE TABLE " + noter_tab_name + "(" + noter_tab_id_noter + " INTEGER PRIMARY KEY AUTOINCREMENT, " + noter_tab_title + " TEXT," + noter_tab_fag + " TEXT," + noter_tab_larer + " TEXT," + noter_tab_description + " TEXT," + noter_tab_img + " TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int DB_VERSION, int newVersion) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + user_tab_name);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + noter_tab_name);
        onCreate(sqLiteDatabase);

    }

    public boolean Insert_user(User user) {

        SQLiteDatabase db_user = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(user_tab_username, user.getUser_name());
        contentValues.put(user_tab_usermail, user.getUser_mail());
        contentValues.put(user_tab_password, user.getUser_pass());
        long result = db_user.insert(user_tab_name, null, contentValues);
        return result != -1;

    }


    public boolean Insert_not(Noter noter) {

        SQLiteDatabase db_not = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(noter_tab_title, noter.getNoter_title());
        contentValues.put(noter_tab_fag, noter.getNoter_fag());
        contentValues.put(noter_tab_larer, noter.getNoter_larer());
        contentValues.put(noter_tab_description, noter.getNoter_des());
        contentValues.put(noter_tab_img, noter.getNoter_img());
        long result = db_not.insert(noter_tab_name, null, contentValues);
        return result != -1;

    }


    public ArrayList<String> getAllusers() {
        ArrayList<String> useres = new ArrayList<>();
        SQLiteDatabase db_user = this.getReadableDatabase();
        Cursor res_user = db_user.rawQuery(" SELECT * FROM " + user_tab_name, null);
        res_user.moveToFirst();

        do {
            String useremail = res_user.getString(2);
            String userpassword = res_user.getString(3);
            //User user = new User(useremail, userpassword);
            useres.add(useremail);
            useres.add(userpassword);
            res_user.moveToNext();

        } while (res_user.moveToNext());
        {
            res_user.close();

        }
        return useres;


    }


    //-----------------------------------------------------------------------------------------

    /* public long get_noter_count() {
        SQLiteDatabase db_noter = getReadableDatabase();
        return DatabaseUtils.queryNumEntries(db_noter, noter_tab_name);

    }*/

    public ArrayList<Noter> getAllnoters() {
        ArrayList<Noter> noters = new ArrayList<>();
        SQLiteDatabase db_noter = this.getReadableDatabase();
        Cursor res_noter = db_noter.rawQuery("select * from " + noter_tab_name, null);

        if (res_noter != null && res_noter.moveToFirst()) {
            do {
                int id = res_noter.getInt(0);
                String noter_title = res_noter.getString(1);
                String noter_fag = res_noter.getString(2);
                String noter_larer = res_noter.getString(3);
                String noter_descp = res_noter.getString(4);
                String noter_img = res_noter.getString(5);
                Noter noter = new Noter(id, noter_title, noter_fag, noter_larer, noter_descp, noter_img);
                noters.add(noter);
                res_noter.moveToNext();
            } while (res_noter.moveToNext());
            res_noter.close();
        }

        return noters;
    }


// avdeling+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


    public boolean login_user(String usermail, String password) {

        if (getAllusers().contains(usermail) && getAllusers().contains(password)) {
           //Log.d("this is allusers",getAllusers());
            return true;
        } else {

            return false;
        }


    }

//end of class--------------------------------------------------

    }







