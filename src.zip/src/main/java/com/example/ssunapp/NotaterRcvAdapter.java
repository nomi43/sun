package com.example.ssunapp;

import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class NotaterRcvAdapter extends RecyclerView.Adapter<NotaterRcvAdapter.NotaterViewHolder> {

    private ArrayList<Noter> noters;
    private ArrayList<Noter> originalListOfNotes; // Field to keep the original list

    public NotaterRcvAdapter(ArrayList<Noter> noters) {

        this.noters = noters;
        this.originalListOfNotes = new ArrayList<>(noters); // Initialize with the original list
    }


    class NotaterViewHolder extends RecyclerView.ViewHolder {

        ImageView imgcardview;
        TextView tv_title;
        TextView tv_fag;
        TextView tv_larer;

        public NotaterViewHolder(View itemView) {


            super(itemView);

            imgcardview = itemView.findViewById(R.id.cardv_img);
            tv_title = itemView.findViewById(R.id.cardv_tv_title);
            tv_fag = itemView.findViewById(R.id.cardv_tv_section);
            tv_larer = itemView.findViewById(R.id.cardv_tv_larer);
        }
    }

    interface OnNoteClickListener {
        void onNoteClick(Noter noter);
    }

    private OnNoteClickListener listener;

    public void setOnNoteClickListener(OnNoteClickListener listener) {
        this.listener = listener;
    }

    @NonNull
    @Override
    public NotaterViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.notater_card_deatil, null, false);
        NotaterViewHolder notaterViewHolder = new NotaterViewHolder(v);
        return notaterViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull NotaterViewHolder holder, int position) {
        Noter n = noters.get(position);

        // Set the image if available, with error handling
        if (n.getNoter_img() != null && !n.getNoter_img().isEmpty()) {
            try {
                Uri imageUri = Uri.parse(n.getNoter_img());
                holder.imgcardview.setImageURI(imageUri);
                holder.imgcardview.setVisibility(View.VISIBLE); // Make sure the ImageView is visible
            } catch (Exception e) {
                e.printStackTrace(); // Log the exception
                // Set a default image or hide the ImageView if the URI is not accessible
                // For example, setting a default image:
                // holder.imgcardview.setImageResource(R.drawable.default_image);

                // Or, to hide the ImageView:
                holder.imgcardview.setVisibility(View.GONE);
            }
        } else {
            // Handle the case where there is no image URL
            // For example, setting a default image or hiding the ImageView
            // holder.imgcardview.setImageResource(R.drawable.default_image);
            holder.imgcardview.setVisibility(View.GONE);
        }

        // Set text for title, section, and teacher. You might want to handle cases where these might be null or empty
        holder.tv_title.setText(n.getNoter_title() != null ? n.getNoter_title() : "");
        holder.tv_fag.setText(n.getNoter_fag() != null ? n.getNoter_fag() : "");
        holder.tv_larer.setText(n.getNoter_larer() != null ? n.getNoter_larer() : "");
    }

    public void setNotes(ArrayList<Noter> noters) {
        this.noters = noters;
        notifyDataSetChanged();
    }
    public void filter(String query) {
        if (query.isEmpty()) {
            setNotes(originalListOfNotes); // Reset to the full list
        } else {
            ArrayList<Noter> filteredList = new ArrayList<>();
            for (Noter noter : originalListOfNotes) {
                if (noter.getNoter_title().toLowerCase().contains(query.toLowerCase()) ||
                        noter.getNoter_des().toLowerCase().contains(query.toLowerCase())) {
                    filteredList.add(noter);
                }
            }
            setNotes(filteredList);
        }
        notifyDataSetChanged();
    }



    @Override
        public int getItemCount () {

            return noters.size();
        }


    }

