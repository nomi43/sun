package com.example.ssunapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    Toolbar toolbar;
    RecyclerView rv;
    FloatingActionButton fabtn;
    SearchView searchView;
    NotaterRcvAdapter notaterRcvAdapter;
    DataBase sqlite;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sqlite = new DataBase(this);
        toolbar = findViewById(R.id.main_activ_toolbar);
        setSupportActionBar(toolbar);

        rv = findViewById(R.id.main_activ_rsv);
        setupRecyclerView();

        fabtn = findViewById(R.id.main_activ_fbut_addnot);
        fabtn.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), ViewNotActivity.class);
            startActivity(intent);
        });
    }

    private void setupRecyclerView() {
        ArrayList<Noter> noters = sqlite.getAllnoters();
        notaterRcvAdapter = new NotaterRcvAdapter(noters);
        rv.setAdapter(notaterRcvAdapter);
        RecyclerView.LayoutManager lm = new GridLayoutManager(this, 2);
        rv.setLayoutManager(lm);
        rv.setHasFixedSize(true);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshNoteList();
    }

    private void refreshNoteList() {
        ArrayList<Noter> noters = sqlite.getAllnoters();
        notaterRcvAdapter.setNotes(noters);
        notaterRcvAdapter.notifyDataSetChanged();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_meny, menu);
        searchView = (SearchView) menu.findItem(R.id.app_bar_search).getActionView();
        setupSearchView();
        return true;
    }

    private void setupSearchView() {
        searchView.setSubmitButtonEnabled(true);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                notaterRcvAdapter.filter(query);
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                notaterRcvAdapter.filter(newText);
                return true;
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        return super.onOptionsItemSelected(item);
    }
}
